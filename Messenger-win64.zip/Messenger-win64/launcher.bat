@echo off
echo ========================================
echo   Messenger - Windows Portable Edition
echo ========================================
echo.
echo Use --server-host to specify a custom server:
echo   run.bat --server-host your-server.com:8080
echo.
pause
