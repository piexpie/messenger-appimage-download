@echo off
set PATH=%~dp0;%PATH%
start "" "%~dp0message_app.exe" %*
